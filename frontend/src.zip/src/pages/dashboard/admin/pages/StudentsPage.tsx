import React from "react";
import AdminDataTable from "../components/AdminDataTable";
import { AdminDashboardResponse, AdminStudent, levelFromEnrollmentYear } from "../adminUtils";

type Props = {
  data: AdminDashboardResponse | null;
  loading: boolean;
  query: string;
  setQuery: (value: string) => void;
  onDelete: (studentNumber: string) => Promise<void> | void;
};

export default function StudentsPage({ data, loading, query, setQuery, onDelete }: Props) {
  const students = (data?.students ?? []).map((student) => ({
    ...student,
    name: `${student.first_name} ${student.last_name}`.trim() || "Unknown student",
    level: levelFromEnrollmentYear(student.enrollment_year),
    status: student.status === "active" ? "Active" : "Review",
  }));

  const filtered = students.filter((student) =>
    `${student.name} ${student.student_number} ${student.program ?? ""}`.toLowerCase().includes(query.toLowerCase())
  );

  const columns = [
    {
      key: "name",
      label: "Student",
      render: (row: typeof students[number]) => (
        <div className="sa-admin-student">
          <strong>{row.name}</strong>
          <small>{row.student_number}</small>
        </div>
      ),
    },
    { key: "program", label: "Program", render: (row: typeof students[number]) => row.program || "Not assigned" },
    { key: "level", label: "Level" },
    {
      key: "status",
      label: "Status",
      render: (row: typeof students[number]) => (
        <div className="sa-inline-actions">
          <span className={`sa-badge ${row.status === "Active" ? "success" : "warning"}`}>{row.status}</span>
          <button type="button" className="sa-button sa-button-outline sa-inline-delete" onClick={() => onDelete(row.student_number)}>Delete</button>
        </div>
      ),
    },
  ];

  return (
    <section className="sa-panel sa-st-flush" aria-labelledby="students-page-title">
      <div className="sa-st-padded">
        <div className="sa-panel-heading" style={{ marginBottom: 8 }}>
          <div>
            <h3 id="students-page-title">Student registry</h3>
            <p>{filtered.length} profiles match the current query</p>
          </div>
        </div>

        <label className="sa-search sa-admin-search">
          ⌕ <input aria-label="Search student records" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search name, student ID, or program" />
        </label>
      </div>

      {loading ? (
        <div className="sa-st-padded">Loading student records…</div>
      ) : (
        <AdminDataTable rows={filtered} columns={columns} emptyLabel="No student records matching your search." />
      )}
    </section>
  );
}
