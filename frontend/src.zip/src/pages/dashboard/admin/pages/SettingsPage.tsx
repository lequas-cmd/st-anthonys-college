import React from "react";

export default function SettingsPage() {
  return (
    <div className="sa-st-report">
      <section className="sa-panel" aria-labelledby="settings-page-title">
        <div className="sa-panel-heading">
          <div>
            <h3 id="settings-page-title">System settings</h3>
            <p>Institutional preferences and controls</p>
          </div>
        </div>

        <div className="sa-task-list">
          <div className="sa-task-row">
            <div className="sa-task-dot" aria-hidden="true">⚙</div>
            <div className="sa-task-info"><strong>Portal access</strong><span>Role-based controls for students, teachers, and administrators</span></div>
            <span className="sa-badge success">Enabled</span>
          </div>
          <div className="sa-task-row">
            <div className="sa-task-dot" aria-hidden="true">▣</div>
            <div className="sa-task-info"><strong>Data sync</strong><span>Sync live records and published updates from the college database</span></div>
            <span className="sa-badge info">Green</span>
          </div>
          <div className="sa-task-row">
            <div className="sa-task-dot" aria-hidden="true">◍</div>
            <div className="sa-task-info"><strong>Audit status</strong><span>Review the latest policy, student, and employee updates</span></div>
            <span className="sa-badge warning">Review</span>
          </div>
        </div>
      </section>
    </div>
  );
}
