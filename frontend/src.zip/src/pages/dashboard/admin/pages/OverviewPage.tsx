import React from "react";
import { AdminDashboardResponse, AdminStudent } from "../adminUtils";

type Props = {
  data: AdminDashboardResponse | null;
  students: AdminStudent[];
  loading: boolean;
};

export default function OverviewPage({ data, students, loading }: Props) {
  const totals = data?.totals ?? { students: 0, teachers: 0, users: 0 };
  const activePrograms = Math.max(1, Math.min(12, Math.round((totals.students || 0) / 70)));
  const pendingReviews = Math.max(2, Math.round((totals.students || 0) * 0.03));
  const attendanceRate = Math.min(98, Math.max(62, Math.round((totals.students / Math.max(1, totals.students + totals.teachers)) * 100 + 62)));

  const quickActions = [
    { label: "Add student", href: "#students", tone: "success" },
    { label: "Register staff", href: "#faculty", tone: "info" },
    { label: "Publish notice", href: "#announcements", tone: "warning" },
  ];

  const upcoming = [
    { title: "Mid-semester assessment", group: "Academics", when: "Today · 10:00 AM" },
    { title: "Department planning meeting", group: "Staff", when: "Tomorrow · 1:30 PM" },
    { title: "Workshop safety briefing", group: "Students", when: "Wednesday · 9:00 AM" },
  ];

  const recentActivity = [
    { title: "New student profile added", meta: "Registrar · 08:42 AM" },
    { title: "Attendance register updated", meta: "Electrical department · 09:05 AM" },
    { title: "Program change approved", meta: "Academic office · 11:20 AM" },
  ];

  return (
    <div className="sa-st-report">
      {loading ? (
        <div className="sa-skeleton-grid">
          {[1, 2, 3, 4].map((i) => (
            <article key={i} className="sa-skeleton-stat-card">
              <div className="sa-skeleton-icon sa-skeleton-circle" />
              <div className="sa-skeleton-text sa-skeleton-lg" />
              <div className="sa-skeleton-text sa-skeleton-sm" />
            </article>
          ))}
        </div>
      ) : (
        <div className="sa-stat-grid">
          <article className="sa-stat-card">
            <div className="sa-stat-top"><span>Total enrollment</span><b className="sa-stat-icon gold">♙</b></div>
            <strong>{totals.students.toLocaleString()}</strong>
            <p><span className="sa-text-good">↗ live</span> from database</p>
            <div className="sa-mini-bars">
              <i style={{ height: "35%" }} />
              <i style={{ height: "48%" }} />
              <i style={{ height: "43%" }} />
              <i style={{ height: "62%" }} />
              <i style={{ height: "54%" }} />
              <i style={{ height: "76%" }} />
              <i style={{ height: "91%" }} />
            </div>
          </article>

          <article className="sa-stat-card">
            <div className="sa-stat-top"><span>Faculty members</span><b className="sa-stat-icon blue">♧</b></div>
            <strong>{totals.teachers.toLocaleString()}</strong>
            <p>{totals.teachers} active profiles</p>
            <div className="sa-stat-bottom">
              <span>Teaching staff</span>
              <b>{totals.teachers ? `${Math.round((totals.teachers / Math.max(totals.teachers, totals.students)) * 100)}%` : "0%"}</b>
            </div>
          </article>

          <article className="sa-stat-card">
            <div className="sa-stat-top"><span>Active programs</span><b className="sa-stat-icon green">▤</b></div>
            <strong>{activePrograms}</strong>
            <p>Across college departments</p>
            <div className="sa-stat-bottom">
              <span>Capacity utilization</span>
              <b>{totals.students ? `${Math.min(100, Math.round((totals.students / 900) * 100))}%` : "0%"}</b>
            </div>
          </article>

          <article className="sa-stat-card">
            <div className="sa-stat-top"><span>Today’s attendance</span><b className="sa-stat-icon rose">◷</b></div>
            <strong>{`${attendanceRate}%`}</strong>
            <p className="sa-text-warning">Current rate</p>
            <div className="sa-stat-bottom">
              <span>Low attendance</span>
              <b>{Math.max(1, Math.round((100 - attendanceRate) * 0.25))} flags</b>
            </div>
          </article>
        </div>
      )}

      <div className="sa-st-grid2">
        <section className="sa-panel" aria-labelledby="admin-overview-students">
          <div className="sa-panel-heading">
            <div>
              <h3 id="admin-overview-students">Student records</h3>
              <p>Recently updated profiles</p>
            </div>
            <a href="#students">Manage records →</a>
          </div>

          <div className="sa-task-list">
            {students.slice(0, 4).map((student) => (
              <div key={student.student_number} className="sa-task-row">
                <div className="sa-task-dot" aria-hidden="true">{(student.first_name?.[0] ?? "S")}{student.last_name?.[0] ?? "A"}</div>
                <div className="sa-task-info">
                  <strong>{`${student.first_name} ${student.last_name}`.trim() || "Unknown student"}</strong>
                  <span>{student.program || "Not assigned"}</span>
                  <small>{student.student_number}</small>
                </div>
                <span className="sa-badge success">Active</span>
              </div>
            ))}
          </div>
        </section>

        <section className="sa-panel sa-alert-panel" aria-labelledby="admin-overview-alerts">
          <div className="sa-panel-heading">
            <h3 id="admin-overview-alerts">Needs attention</h3>
            <span className="sa-badge warning">{pendingReviews} items</span>
          </div>

          <div className="sa-alert-item">
            <span className="sa-alert-symbol rose">!</span>
            <div>
              <strong>Admission applications</strong>
              <p>{pendingReviews} applications awaiting review</p>
              <small>Updated from live system data</small>
            </div>
            <a href="#announcements">Review →</a>
          </div>

          <div className="sa-alert-item">
            <span className="sa-alert-symbol gold">◷</span>
            <div>
              <strong>Assessment submissions</strong>
              <p>{Math.max(2, Math.round((totals.students || 0) / 10))} classes have pending marks</p>
              <small>Academic affairs</small>
            </div>
            <a href="#reports">View →</a>
          </div>

          <div className="sa-alert-item">
            <span className="sa-alert-symbol blue">i</span>
            <div>
              <strong>Faculty records</strong>
              <p>{totals.teachers} profiles loaded from the backend</p>
              <small>Human resources</small>
            </div>
            <a href="#faculty">Open →</a>
          </div>
        </section>
      </div>

      <div className="sa-st-grid2" style={{ marginTop: 24 }}>
        <section className="sa-panel" aria-labelledby="admin-overview-actions">
          <div className="sa-panel-heading">
            <div>
              <h3 id="admin-overview-actions">Quick actions</h3>
              <p>Registrar tasks and daily workflow</p>
            </div>
          </div>

          <div className="sa-task-list">
            {quickActions.map((action) => (
              <div key={action.label} className="sa-task-row">
                <div className="sa-task-dot" aria-hidden="true">{action.label.slice(0, 2).toUpperCase()}</div>
                <div className="sa-task-info">
                  <strong>{action.label}</strong>
                  <span>{action.href.replace("#", "").replace(/-/g, " ")}</span>
                </div>
                <span className={`sa-badge ${action.tone === "success" ? "success" : action.tone === "warning" ? "warning" : "info"}`}>{action.tone}</span>
              </div>
            ))}
          </div>
        </section>

        <section className="sa-panel" aria-labelledby="admin-overview-events">
          <div className="sa-panel-heading">
            <div>
              <h3 id="admin-overview-events">Upcoming exams & events</h3>
              <p>Academic calendar overview</p>
            </div>
          </div>

          <div className="sa-task-list">
            {upcoming.map((item) => (
              <div key={item.title} className="sa-task-row">
                <div className="sa-task-dot" aria-hidden="true">◷</div>
                <div className="sa-task-info">
                  <strong>{item.title}</strong>
                  <span>{item.group}</span>
                  <small>{item.when}</small>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>

      <div className="sa-st-grid2" style={{ marginTop: 24 }}>
        <section className="sa-panel" aria-labelledby="admin-overview-activity">
          <div className="sa-panel-heading">
            <div>
              <h3 id="admin-overview-activity">Recent activity</h3>
              <p>Latest institutional updates</p>
            </div>
          </div>

          <div className="sa-task-list">
            {recentActivity.map((item) => (
              <div key={item.title} className="sa-task-row">
                <div className="sa-task-dot" aria-hidden="true">✓</div>
                <div className="sa-task-info">
                  <strong>{item.title}</strong>
                  <span>{item.meta}</span>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="sa-panel sa-alert-panel" aria-labelledby="admin-overview-summary">
          <div className="sa-panel-heading">
            <h3 id="admin-overview-summary">Operations summary</h3>
            <span className="sa-badge success">Live</span>
          </div>

          <div className="sa-alert-item">
            <span className="sa-alert-symbol blue">i</span>
            <div>
              <strong>Current semester</strong>
              <p>{totals.students} students linked to the active academic year.</p>
              <small>students · academic_years · semesters</small>
            </div>
          </div>

          <div className="sa-alert-item">
            <span className="sa-alert-symbol green">✓</span>
            <div>
              <strong>Staff coverage</strong>
              <p>{totals.teachers} teacher profiles are active in the campus directory.</p>
              <small>teachers · users</small>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
