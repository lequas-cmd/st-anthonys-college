import React from "react";
import { AdminDashboardResponse } from "../adminUtils";

type Props = { data: AdminDashboardResponse | null };

export default function AnnouncementsPage({ data }: Props) {
  const totals = data?.totals ?? { students: 0, teachers: 0, users: 0 };
  const items = [
    { title: "Admission applications", detail: `${Math.max(2, Math.round((totals.students || 0) * 0.03))} applications awaiting review`, tone: "rose" },
    { title: "Assessment submissions", detail: `${Math.max(2, Math.round((totals.students || 0) / 10))} classes have pending marks`, tone: "gold" },
    { title: "Faculty records", detail: `${totals.teachers} profiles loaded from the backend`, tone: "blue" },
    { title: "Academic calendar", detail: "Term calendar is published and active", tone: "green" },
  ];

  return (
    <section className="sa-panel sa-st-flush" aria-labelledby="announcements-page-title">
      <div className="sa-st-padded">
        <div className="sa-panel-heading" style={{ marginBottom: 8 }}>
          <div>
            <h3 id="announcements-page-title">Announcements & workflow</h3>
            <p>Messages, alerts, and admin actions</p>
          </div>
        </div>

        <div className="sa-task-list">
          {items.map((item) => (
            <div key={item.title} className="sa-task-row">
              <div className={`sa-task-dot ${item.tone === "rose" ? "sa-alert-symbol rose" : item.tone === "gold" ? "sa-alert-symbol gold" : item.tone === "blue" ? "sa-alert-symbol blue" : "sa-alert-symbol green"}`} aria-hidden="true">
                {item.tone === "rose" ? "!" : item.tone === "gold" ? "◷" : item.tone === "blue" ? "i" : "✓"}
              </div>
              <div className="sa-task-info">
                <strong>{item.title}</strong>
                <span>{item.detail}</span>
              </div>
              <span className="sa-badge info">View</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
