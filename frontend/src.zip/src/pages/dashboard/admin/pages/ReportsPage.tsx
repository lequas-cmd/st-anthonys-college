import React from "react";
import { AdminDashboardResponse } from "../adminUtils";

type Props = { data: AdminDashboardResponse | null };

export default function ReportsPage({ data }: Props) {
  const totals = data?.totals ?? { students: 0, teachers: 0, users: 0 };
  const rows = [
    { label: "Student retention", value: 82, tone: "ok" },
    { label: "Completion rate", value: 76, tone: "ok" },
    { label: "Attendance compliance", value: 68, tone: "low" },
    { label: "Assessment coverage", value: 89, tone: "ok" },
  ];

  return (
    <section className="sa-panel sa-st-flush" aria-labelledby="reports-page-title">
      <div className="sa-st-padded">
        <div className="sa-panel-heading" style={{ marginBottom: 8 }}>
          <div>
            <h3 id="reports-page-title">Institutional activity</h3>
            <p>Performance signals from the current academic cycle</p>
          </div>
        </div>

        <ul className="sa-st-bars" style={{ padding: 0, margin: 0 }}>
          {rows.map((row) => (
            <li key={row.label}>
              <span className="sa-st-bar-label"><b>{row.label}</b><small>Current cycle</small></span>
              <span className="sa-st-bar-track" aria-hidden="true">
                <i className={row.tone} style={{ width: `${row.value}%` }} />
                <em style={{ left: "50%" }} />
              </span>
              <span className="sa-st-bar-value">{row.value}%</span>
            </li>
          ))}
        </ul>

        <div className="sa-task-list" style={{ marginTop: 24 }}>
          <div className="sa-task-row">
            <div className="sa-task-dot" aria-hidden="true">✓</div>
            <div className="sa-task-info"><strong>Academic calendar published</strong><span>Registrar’s office · 10:42 AM</span></div>
            <span className="sa-badge success">Complete</span>
          </div>
          <div className="sa-task-row">
            <div className="sa-task-dot" aria-hidden="true">◷</div>
            <div className="sa-task-info"><strong>{totals.teachers} faculty profiles loaded</strong><span>Human resources · Today</span></div>
            <span className="sa-badge info">Live</span>
          </div>
          <div className="sa-task-row">
            <div className="sa-task-dot" aria-hidden="true">!</div>
            <div className="sa-task-info"><strong>Assessment period opened</strong><span>Academic affairs · today</span></div>
            <span className="sa-badge warning">Attention</span>
          </div>
        </div>
      </div>
    </section>
  );
}
