import React, { useEffect, useMemo, useState } from "react";

export type CrudField = {
  name: string;
  label: string;
  type?: "text" | "number" | "email" | "password" | "textarea";
  placeholder?: string;
  defaultValue?: string | number;
  required?: boolean;
};

type Props = {
  open: boolean;
  title: string;
  submitLabel: string;
  fields: CrudField[];
  onClose: () => void;
  onSubmit: (values: Record<string, string>) => Promise<void> | void;
};

export default function AdminCrudModal({ open, title, submitLabel, fields, onClose, onSubmit }: Props) {
  const initialValues = useMemo(() => Object.fromEntries(fields.map((field) => [field.name, String(field.defaultValue ?? "")])), [fields]);
  const [values, setValues] = useState<Record<string, string>>(initialValues);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setValues(initialValues);
    setSaving(false);
  }, [initialValues, open]);

  if (!open) return null;

  const handleChange = (name: string, value: string) => setValues((current) => ({ ...current, [name]: value }));

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setSaving(true);
    try {
      await onSubmit(values);
      onClose();
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="sa-modal-backdrop" role="dialog" aria-modal="true" aria-labelledby="admin-modal-title" onClick={onClose}>
      <div className="sa-modal" onClick={(event) => event.stopPropagation()}>
        <div className="sa-modal-header">
          <div>
            <div className="sa-eyebrow">ADMIN ACTION</div>
            <h3 id="admin-modal-title">{title}</h3>
          </div>
          <button type="button" className="sa-link-button" onClick={onClose}>Close ✕</button>
        </div>

        <form onSubmit={handleSubmit} className="sa-modal-form">
          {fields.map((field) => (
            <label key={field.name} className="sa-modal-field">
              <span>{field.label}</span>
              {field.type === "textarea" ? (
                <textarea
                  value={values[field.name] ?? ""}
                  required={field.required}
                  placeholder={field.placeholder}
                  onChange={(event) => handleChange(field.name, event.target.value)}
                  rows={4}
                />
              ) : (
                <input
                  type={field.type ?? "text"}
                  value={values[field.name] ?? ""}
                  required={field.required}
                  placeholder={field.placeholder}
                  onChange={(event) => handleChange(field.name, event.target.value)}
                />
              )}
            </label>
          ))}

          <div className="sa-modal-actions">
            <button type="button" className="sa-button sa-button-outline" onClick={onClose}>Cancel</button>
            <button type="submit" className="sa-button sa-button-primary" disabled={saving}>{saving ? "Saving…" : submitLabel}</button>
          </div>
        </form>
      </div>
    </div>
  );
}
