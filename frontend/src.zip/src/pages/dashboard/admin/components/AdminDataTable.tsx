import React from "react";

type Column<T> = {
  key: keyof T | string;
  label: string;
  render?: (row: T) => React.ReactNode;
  className?: string;
};

type Props<T extends Record<string, unknown>> = {
  columns: Column<T>[];
  rows: T[];
  emptyLabel?: string;
  onSort?: (key: string) => void;
};

export default function AdminDataTable<T extends Record<string, unknown>>({
  columns,
  rows,
  emptyLabel = "No records available.",
  onSort,
}: Props<T>) {
  return (
    <div className="sa-table-wrap">
      <table className="sa-table sa-admin-table">
        <thead>
          <tr>
            {columns.map((column) => (
              <th key={String(column.key)}>
                {onSort ? (
                  <button type="button" className="sa-link-button" onClick={() => onSort(String(column.key))}>
                    {column.label}
                  </button>
                ) : (
                  column.label
                )}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.length ? (
            rows.map((row, index) => (
              <tr key={index}>
                {columns.map((column) => (
                  <td key={`${String(column.key)}-${index}`} className={column.className}>
                    {column.render ? column.render(row) : String(row[column.key as keyof T] ?? "")}
                  </td>
                ))}
              </tr>
            ))
          ) : (
            <tr><td colSpan={columns.length}>{emptyLabel}</td></tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
