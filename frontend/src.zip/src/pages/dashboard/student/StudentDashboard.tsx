import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  BarChart3,
  BookOpenText,
  CalendarDays,
  House,
  LogOut,
} from "lucide-react";
import "../../../styles/dashboard/shared.css";
import "../../../styles/dashboard/student.css";
import { apiRequest } from "../../../services/api";
import SkeletonLoader from "../../../components/SkeletonLoader";
import {
  buildCourseGrades,
  selectCurrentCourses,
  StudentSummary,
} from "./utils/studentUtils";
import OverviewPage from "./pages/OverviewPage";
import SchedulePage from "./pages/SchedulePage";
import ResourcesPage from "./pages/ResourcesPage";
import GradeReportPage from "./pages/GradeReportPage";

type DashboardTab = "overview" | "schedule" | "grades" | "resources";

export default function StudentDashboard() {
  const [data, setData] = useState<StudentSummary | null>(null);
  const [courses, setCourses] = useState<ReturnType<typeof buildCourseGrades>>(
    [],
  );
  const [tab, setTab] = useState<DashboardTab>("overview");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    let active = true;

    const loadDashboard = async () => {
      try {
        const payload = await apiRequest<StudentSummary>("/dashboard/student");
        if (active) {
          setData(payload);
          const all = buildCourseGrades(payload.grades ?? []);
          setCourses(selectCurrentCourses(all));
        }
      } catch (err) {
        if (active) {
          setError(
            err instanceof Error
              ? err.message
              : "Could not load dashboard data.",
          );
        }
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    };

    loadDashboard();
    return () => {
      active = false;
    };
  }, []);

  const currentCourses = useMemo(
    () => selectCurrentCourses(courses),
    [courses],
  );

  const onNavigate = (next: "schedule" | "grades") =>
    setTab(next === "schedule" ? "schedule" : "grades");
  const handleLogout = () => {
    localStorage.removeItem("collegeAuthToken");
    localStorage.removeItem("collegeUser");
    sessionStorage.removeItem("collegeSessionToken");
    sessionStorage.removeItem("collegeUser");
    navigate("/login", { replace: true });
  };

  return (
    <div className="sa-dashboard">
      <aside
        className={`sa-sidebar ${isSidebarOpen ? "is-open" : ""}`}
        aria-expanded={isSidebarOpen}
        aria-label="Student sidebar navigation"
      >
        <div className="sa-sidebar-header">
          <div className="sa-brand">
            <div className="sa-crest">SA</div>
            <div>
              <strong>SAINT ANTHONY'S</strong>
              <span>TECHNICAL COLLEGE</span>
            </div>
          </div>
          <button
            type="button"
            className="sa-sidebar-close"
            aria-label="Close navigation"
            onClick={() => setIsSidebarOpen(false)}
          >
            ×
          </button>
        </div>
        <div className="sa-role">STUDENT PORTAL</div>
        <nav className="sa-nav">
          <a
            className={tab === "overview" ? "active" : ""}
            href="#overview"
            onClick={() => {
              setTab("overview");
              setIsSidebarOpen(false);
            }}
          >
            <span className="sa-nav-icon">
              <House size={15} />
            </span>{" "}
            Overview
          </a>
          <a
            className={tab === "schedule" ? "active" : ""}
            href="#schedule"
            onClick={() => {
              setTab("schedule");
              setIsSidebarOpen(false);
            }}
          >
            <span className="sa-nav-icon">
              <CalendarDays size={15} />
            </span>{" "}
            Schedule
          </a>
          <a
            className={tab === "grades" ? "active" : ""}
            href="#grades"
            onClick={() => {
              setTab("grades");
              setIsSidebarOpen(false);
            }}
          >
            <span className="sa-nav-icon">
              <BarChart3 size={15} />
            </span>{" "}
            Grades
          </a>
          <a
            className={tab === "resources" ? "active" : ""}
            href="#resources"
            onClick={() => {
              setTab("resources");
              setIsSidebarOpen(false);
            }}
          >
            <span className="sa-nav-icon">
              <BookOpenText size={15} />
            </span>{" "}
            Resources
          </a>
        </nav>
        <div className="sa-sidebar-logout">
          <button
            type="button"
            className="sa-logout-btn"
            onClick={handleLogout}
          >
            <LogOut size={14} /> Logout
          </button>
        </div>
        <div className="sa-sidebar-bottom">
          <div className="sa-help-icon">?</div>
          <div>
            <strong>Student support</strong>
            <span>Academic help desk</span>
          </div>
          <span className="sa-chevron">›</span>
        </div>
      </aside>
      <main className="sa-main">
        <header className="sa-topbar">
          <button
            type="button"
            className="sa-mobile-menu-toggle"
            aria-label={isSidebarOpen ? "Close navigation" : "Open navigation"}
            aria-expanded={isSidebarOpen}
            onClick={() => setIsSidebarOpen((open) => !open)}
          >
            ☰
          </button>
          <div className="sa-breadcrumb">
            Student <span>/</span> {tab.charAt(0).toUpperCase() + tab.slice(1)}
          </div>
          
        </header>
        <section className="sa-content">
          {error && (
            <div className="sa-alert-panel" style={{ marginBottom: 20 }}>
              <strong>Live data unavailable:</strong> {error}
            </div>
          )}
          {loading ? <SkeletonLoader /> : tab === "overview" ? (
            <OverviewPage
              data={data!}
              courses={currentCourses}
              onNavigate={onNavigate}
            />
          ) : tab === "schedule" ? (
            <SchedulePage data={data!} />
          ) : tab === "resources" ? (
            <ResourcesPage data={data!} onNotify={() => {}} />
          ) : (
            <GradeReportPage
              data={data!}
              courses={currentCourses}
              onNotify={() => {}}
            />
          )}
        </section>
      </main>
    </div>
  );
}
