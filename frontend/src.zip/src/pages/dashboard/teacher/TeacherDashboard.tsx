import React, { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  BarChart3,
  BookOpenText,
  CalendarDays,
  ClipboardCheck,
  FileText,
  House,
  LogOut,
  Megaphone,
  UserRound,
} from "lucide-react";
import "../../../styles/dashboard/shared.css";
import "../../../styles/dashboard/student.css";
import { apiRequest } from "../../../services/api";
import AdminCrudModal, { CrudField } from "../admin/components/AdminCrudModal";
import SkeletonLoader from "../../../components/SkeletonLoader";
import OverviewPage from "./pages/OverviewPage";
import ClassesPage from "./pages/ClassesPage";
import GradebookPage from "./pages/GradebookPage";
import AttendancePage from "./pages/AttendancePage";
import ResourcesPage from "./pages/ResourcesPage";
import AnnouncementsPage from "./pages/AnnouncementsPage";
import ProfilePage from "./pages/ProfilePage";

export type TeacherRecord = {
  id?: number;
  employee_number?: string;
  first_name?: string;
  last_name?: string;
  department?: string | null;
  status?: string | null;
};

export type TeacherGradeCell = {
  grade_id: number | null;
  value: number | null;
  locked_at: string | null;
  max_score: number;
};

export type TeacherRosterStudent = {
  id: number;
  student_number: string;
  first_name: string;
  last_name: string;
  program: string;
  attendance_pct: number;
  current_grade_value: number | null;
  current_grade: string;
  grades: Record<number, TeacherGradeCell>;
};

export type TeacherAssessment = {
  id: number;
  title: string;
  type: string;
  max_score: number;
  weight: number;
  due_date: string | null;
  published: boolean;
};

export type TeacherClass = {
  id: number;
  course_code: string;
  course_title: string;
  section: string;
  room: string;
  semester_name: string;
  student_count: number;
  next_class: string;
  pending_grades: number;
  roster: TeacherRosterStudent[];
  assessments: TeacherAssessment[];
  announcements: Array<{
    id: number;
    title: string;
    body: string;
    audience: string;
    published_at: string;
    link_url?: string;
  }>;
  timetable: Array<{
    day: string;
    time: string;
    room: string;
    course_title: string;
  }>;
};

export type TeacherDashboardResponse = {
  teacher: {
    id: number;
    employee_number: string;
    first_name: string;
    last_name: string;
    department: string;
    status: string;
  };
  totals: {
    courses: number;
    pending_grades: number;
    low_attendance: number;
    announcements: number;
  };
  classes: TeacherClass[];
  announcements: Array<{
    id: number;
    title: string;
    body: string;
    audience: string;
    published_at: string;
    link_url?: string;
  }>;
};

export type TeacherTab =
  | "overview"
  | "classes"
  | "gradebook"
  | "attendance"
  | "timetable"
  | "announcements"
  | "profile";

const createFallbackTeacherDashboard = (): TeacherDashboardResponse => ({
  teacher: {
    id: 101,
    employee_number: "TE-1001",
    first_name: "Daniel",
    last_name: "Tadesse",
    department: "Computer Science",
    status: "active",
  },
  totals: {
    courses: 3,
    pending_grades: 8,
    low_attendance: 4,
    announcements: 2,
  },
  classes: [
    {
      id: 201,
      course_code: "CS-201",
      course_title: "Programming Fundamentals",
      section: "Section A",
      room: "Lab 3",
      semester_name: "2026 Fall",
      student_count: 24,
      next_class: "Tue, 09:00 AM",
      pending_grades: 5,
      roster: [
        {
          id: 1,
          student_number: "ST-2026-001",
          first_name: "Amina",
          last_name: "Bekele",
          program: "Computer Science",
          attendance_pct: 92,
          current_grade_value: 86,
          current_grade: "86%",
          grades: {
            301: { grade_id: 401, value: 88, locked_at: null, max_score: 100 },
            302: { grade_id: 402, value: 84, locked_at: null, max_score: 100 },
          },
        },
        {
          id: 2,
          student_number: "ST-2026-002",
          first_name: "Biruk",
          last_name: "Desta",
          program: "Computer Science",
          attendance_pct: 80,
          current_grade_value: 78,
          current_grade: "78%",
          grades: {
            301: { grade_id: 403, value: 79, locked_at: null, max_score: 100 },
            302: { grade_id: 404, value: 77, locked_at: null, max_score: 100 },
          },
        },
        {
          id: 3,
          student_number: "ST-2026-003",
          first_name: "Selam",
          last_name: "Hailu",
          program: "Software Engineering",
          attendance_pct: 69,
          current_grade_value: 71,
          current_grade: "71%",
          grades: {
            301: { grade_id: 405, value: 72, locked_at: null, max_score: 100 },
            302: { grade_id: 406, value: 70, locked_at: null, max_score: 100 },
          },
        },
      ],
      assessments: [
        {
          id: 301,
          title: "Quiz 1",
          type: "quiz",
          max_score: 100,
          weight: 20,
          due_date: "2026-11-09",
          published: true,
        },
        {
          id: 302,
          title: "Practical Lab",
          type: "practical",
          max_score: 100,
          weight: 30,
          due_date: "2026-11-12",
          published: true,
        },
      ],
      announcements: [
        {
          id: 1,
          title: "Lab session reminder",
          body: "Please review the numbered exercises before tomorrow's lab.",
          audience: "students",
          published_at: "2026-11-03T08:30:00.000Z",
        },
      ],
      timetable: [
        {
          day: "Mon",
          time: "09:00 - 11:00",
          room: "Lab 3",
          course_title: "Programming Fundamentals",
        },
        {
          day: "Wed",
          time: "13:00 - 15:00",
          room: "Lab 3",
          course_title: "Programming Fundamentals",
        },
      ],
    },
    {
      id: 202,
      course_code: "CS-240",
      course_title: "Database Systems",
      section: "Section B",
      room: "Room 12",
      semester_name: "2026 Fall",
      student_count: 21,
      next_class: "Thu, 10:00 AM",
      pending_grades: 3,
      roster: [
        {
          id: 11,
          student_number: "ST-2026-011",
          first_name: "Mekdes",
          last_name: "Abebe",
          program: "Information Systems",
          attendance_pct: 88,
          current_grade_value: 90,
          current_grade: "90%",
          grades: {},
        },
        {
          id: 12,
          student_number: "ST-2026-012",
          first_name: "Yohannes",
          last_name: "Girma",
          program: "Information Systems",
          attendance_pct: 76,
          current_grade_value: 74,
          current_grade: "74%",
          grades: {},
        },
      ],
      assessments: [
        {
          id: 321,
          title: "ER Diagram",
          type: "assignment",
          max_score: 100,
          weight: 25,
          due_date: "2026-11-14",
          published: true,
        },
      ],
      announcements: [],
      timetable: [
        {
          day: "Tue",
          time: "08:00 - 10:00",
          room: "Room 12",
          course_title: "Database Systems",
        },
      ],
    },
  ],
  announcements: [
    {
      id: 91,
      title: "Assessment deadline reminder",
      body: "Final submissions for continuing assessment close Friday at 5:00 PM.",
      audience: "teachers",
      published_at: "2026-11-05T07:00:00.000Z",
    },
  ],
});

const tabLabels: Record<TeacherTab, string> = {
  overview: "Home",
  classes: "My courses",
  gradebook: "Gradebook",
  attendance: "Attendance",
  timetable: "Timetable",
  announcements: "Announcements",
  profile: "Profile",
};

type TeacherModalState = {
  title: string;
  submitLabel: string;
  fields: CrudField[];
  onSubmit: (values: Record<string, string>) => Promise<void> | void;
};

export default function TeacherDashboard() {
  const [tab, setTab] = useState<TeacherTab>("overview");
  const [summary, setSummary] = useState<TeacherDashboardResponse | null>(
    createFallbackTeacherDashboard(),
  );
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [modal, setModal] = useState<TeacherModalState | null>(null);
  const [selectedClassId, setSelectedClassId] = useState<number | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const navigate = useNavigate();
  const params = useParams<{ section?: string; classId?: string }>();

  useEffect(() => {
    const section = params.section ?? "overview";
    if (
      section === "overview" ||
      section === "classes" ||
      section === "gradebook" ||
      section === "attendance" ||
      section === "timetable" ||
      section === "announcements" ||
      section === "profile"
    ) {
      setTab(section);
    }
  }, [params.section]);

  useEffect(() => {
    let active = true;

    const loadDashboard = async () => {
      try {
        const data =
          await apiRequest<TeacherDashboardResponse>("/dashboard/teacher");
        if (active) {
          const resolved =
            data && typeof data === "object"
              ? data
              : createFallbackTeacherDashboard();
          const classList = resolved.classes ?? [];
          setSummary(resolved);
          if (classList.length) {
            const targetClassId = Number(params.classId ?? classList[0].id);
            const nextId = Number.isFinite(targetClassId)
              ? targetClassId
              : classList[0].id;
            const exists = classList.some((cls) => cls.id === nextId);
            setSelectedClassId(exists ? nextId : classList[0].id);
          } else {
            setSelectedClassId(null);
          }
        }
      } catch (err) {
        if (active) {
          const fallback = createFallbackTeacherDashboard();
          setSummary(fallback);
          setError(
            err instanceof Error
              ? err.message
              : "Could not load teacher dashboard data.",
          );
        }
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    };

    loadDashboard();
    return () => {
      active = false;
    };
  }, [params.classId]);

  const dashboardData = summary ?? createFallbackTeacherDashboard();
  const dashboardClasses = dashboardData.classes ?? [];

  const currentClass = useMemo(() => {
    if (!dashboardData) return null;
    if (selectedClassId) {
      return (
        dashboardClasses.find((cls) => cls.id === selectedClassId) ??
        dashboardClasses[0] ??
        null
      );
    }
    return dashboardClasses[0] ?? null;
  }, [dashboardClasses, dashboardData, selectedClassId]);

  const handleSelectClass = (nextClassId: number) => {
    setSelectedClassId(nextClassId);
    navigate(`/dashboard/teacher/gradebook/${nextClassId}`);
  };

  const handleLogout = () => {
    localStorage.removeItem("collegeAuthToken");
    localStorage.removeItem("collegeUser");
    sessionStorage.removeItem("collegeSessionToken");
    sessionStorage.removeItem("collegeUser");
    navigate("/login", { replace: true });
  };

  const openAddModal = (
    entity: "class" | "assessment" | "attendance" | "resource",
  ) => {
    const configMap: Record<
      typeof entity,
      { title: string; submitLabel: string; fields: CrudField[] }
    > = {
      class: {
        title: "Add new class",
        submitLabel: "Create class",
        fields: [
          {
            name: "title",
            label: "Class title",
            placeholder: "Electrical Installation",
            required: true,
          },
          {
            name: "code",
            label: "Course code",
            placeholder: "ELT-204",
            required: true,
          },
          { name: "section", label: "Section", placeholder: "Section B" },
          { name: "room", label: "Room", placeholder: "Lab 04" },
        ],
      },
      assessment: {
        title: "Add assessment",
        submitLabel: "Create assessment",
        fields: [
          {
            name: "title",
            label: "Assessment title",
            placeholder: "Practical quiz",
            required: true,
          },
          {
            name: "course",
            label: "Course",
            placeholder: "ELT 204",
            required: true,
          },
          {
            name: "date",
            label: "Date",
            type: "text",
            placeholder: "2026-11-12",
          },
          {
            name: "max_score",
            label: "Max score",
            type: "number",
            placeholder: "20",
          },
        ],
      },
      attendance: {
        title: "Add attendance record",
        submitLabel: "Save attendance",
        fields: [
          {
            name: "student",
            label: "Student name",
            placeholder: "Amina Bekele",
            required: true,
          },
          { name: "status", label: "Status", placeholder: "Present" },
          { name: "date", label: "Session date", placeholder: "2026-11-05" },
        ],
      },
      resource: {
        title: "Add teaching resource",
        submitLabel: "Save resource",
        fields: [
          {
            name: "title",
            label: "Resource title",
            placeholder: "Workshop notes",
            required: true,
          },
          { name: "type", label: "Type", placeholder: "Guide" },
          { name: "updated", label: "Updated on", placeholder: "2026-11-05" },
        ],
      },
    };

    const config = configMap[entity];
    setModal({
      title: config.title,
      submitLabel: config.submitLabel,
      fields: config.fields,
      onSubmit: async () => {
        if (entity === "assessment" && currentClass) {
          window.alert(`Assessment added for ${currentClass.course_title}.`);
        }
      },
    });
  };

  const renderPage = () => {
    if (tab === "overview") {
      return <OverviewPage data={summary} loading={loading} />;
    }
    if (tab === "classes") {
      return (
        <ClassesPage
          data={summary}
          loading={loading}
          onOpenGradebook={handleSelectClass}
        />
      );
    }
    if (tab === "gradebook") {
      return (
        <GradebookPage
          classes={dashboardClasses}
          selectedClassId={selectedClassId}
          loading={loading}
          onSelectClass={handleSelectClass}
        />
      );
    }
    if (tab === "attendance") {
      return <AttendancePage data={summary} loading={loading} />;
    }
    if (tab === "timetable") {
      return <ResourcesPage data={summary} loading={loading} />;
    }
    if (tab === "announcements") {
      return <AnnouncementsPage data={summary} loading={loading} />;
    }
    return <ProfilePage data={summary} loading={loading} />;
  };

  return (
    <div className="sa-dashboard sa-student">
      <aside
        className={`sa-sidebar ${isSidebarOpen ? "is-open" : ""}`}
        aria-expanded={isSidebarOpen}
        aria-label="Teacher sidebar navigation"
      >
        <div className="sa-sidebar-header">
          <div className="sa-brand">
            <div className="sa-crest">SA</div>
            <div>
              <strong>SAINT ANTHONY'S</strong>
              <span>TECHNICAL COLLEGE</span>
            </div>
          </div>
          <button
            type="button"
            className="sa-sidebar-close"
            aria-label="Close navigation"
            onClick={() => setIsSidebarOpen(false)}
          >
            ×
          </button>
        </div>
        <div className="sa-role">FACULTY WORKSPACE</div>
        <nav className="sa-nav">
          <a
            className={tab === "overview" ? "active" : ""}
            href="#overview"
            onClick={() => {
              setTab("overview");
              setIsSidebarOpen(false);
            }}
          >
            <span className="sa-nav-icon">
              <House size={15} />
            </span>{" "}
            Home
          </a>
          <a
            className={tab === "classes" ? "active" : ""}
            href="#classes"
            onClick={() => {
              setTab("classes");
              setIsSidebarOpen(false);
            }}
          >
            <span className="sa-nav-icon">
              <BookOpenText size={15} />
            </span>{" "}
            My courses
          </a>
          <a
            className={tab === "gradebook" ? "active" : ""}
            href="#gradebook"
            onClick={() => {
              setTab("gradebook");
              setIsSidebarOpen(false);
            }}
          >
            <span className="sa-nav-icon">
              <FileText size={15} />
            </span>{" "}
            Gradebook
          </a>
          <a
            className={tab === "attendance" ? "active" : ""}
            href="#attendance"
            onClick={() => {
              setTab("attendance");
              setIsSidebarOpen(false);
            }}
          >
            <span className="sa-nav-icon">
              <ClipboardCheck size={15} />
            </span>{" "}
            Attendance
          </a>
          <a
            className={tab === "timetable" ? "active" : ""}
            href="#timetable"
            onClick={() => {
              setTab("timetable");
              setIsSidebarOpen(false);
            }}
          >
            <span className="sa-nav-icon">
              <CalendarDays size={15} />
            </span>{" "}
            Timetable
          </a>
          <a
            className={tab === "announcements" ? "active" : ""}
            href="#announcements"
            onClick={() => {
              setTab("announcements");
              setIsSidebarOpen(false);
            }}
          >
            <span className="sa-nav-icon">
              <Megaphone size={15} />
            </span>{" "}
            Announcements
          </a>
          <a
            className={tab === "profile" ? "active" : ""}
            href="#profile"
            onClick={() => {
              setTab("profile");
              setIsSidebarOpen(false);
            }}
          >
            <span className="sa-nav-icon">
              <UserRound size={15} />
            </span>{" "}
            Profile
          </a>
        </nav>
        <div className="sa-sidebar-logout">
          <button
            type="button"
            className="sa-logout-btn"
            onClick={handleLogout}
          >
            <LogOut size={14} /> Logout
          </button>
        </div>
        <div className="sa-sidebar-bottom">
          <div className="sa-help-icon">?</div>
          <div>
            <strong>Faculty support</strong>
            <span>Teaching & learning office</span>
          </div>
          <span className="sa-chevron">›</span>
        </div>
      </aside>

      <main className="sa-main">
        <header className="sa-topbar">
          <button
            type="button"
            className="sa-mobile-menu-toggle"
            aria-label={isSidebarOpen ? "Close navigation" : "Open navigation"}
            aria-expanded={isSidebarOpen}
            onClick={() => setIsSidebarOpen((open) => !open)}
          >
            ☰
          </button>
          <div className="sa-breadcrumb">
            Faculty Workspace <span>/</span> {tabLabels[tab]}
          </div>
          
        </header>

        <section className="sa-content">
          {error && (
            <div className="sa-alert-panel" style={{ marginBottom: 20 }}>
              <strong>Live data unavailable:</strong> {error}
            </div>
          )}

          <div className="sa-page-heading">
            <div>
              <div className="sa-eyebrow">FACULTY WORKSPACE / TEACHING</div>
              <h1>{tabLabels[tab]}</h1>
              <p>Manage classes, attendance, grades, and learning resources.</p>
            </div>

            <div className="sa-heading-actions">
              <button
                className="sa-button sa-button-primary"
                type="button"
                onClick={() => {
                  if (tab === "classes") openAddModal("class");
                  else if (tab === "gradebook") openAddModal("assessment");
                  else if (tab === "attendance") openAddModal("attendance");
                  else if (tab === "timetable") openAddModal("resource");
                  else if (tab === "announcements") openAddModal("resource");
                  else openAddModal("class");
                }}
              >
                ＋ <span>Add</span>
              </button>
              <button
                className="sa-button sa-button-outline"
                type="button"
                onClick={() => window.print()}
              >
                ⇩ <span>Export</span>
              </button>
            </div>
          </div>

          {loading ? <SkeletonLoader /> : renderPage()}
        </section>
      </main>

      {modal && (
        <AdminCrudModal
          open={!!modal}
          title={modal.title}
          submitLabel={modal.submitLabel}
          fields={modal.fields}
          onClose={() => setModal(null)}
          onSubmit={async (values) => {
            await modal.onSubmit(values);
            setModal(null);
          }}
        />
      )}
    </div>
  );
}
