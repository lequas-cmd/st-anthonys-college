import React from "react";
import type { TeacherDashboardResponse } from "../TeacherDashboard";

type Props = { data: TeacherDashboardResponse | null; loading: boolean; };

export default function AnnouncementsPage({ data, loading }: Props) {
  const items = data?.announcements ?? [];

  return (
    <section className="sa-panel sa-st-flush" aria-labelledby="teacher-announcements-title">
      <div className="sa-st-padded">
        <div className="sa-panel-heading" style={{ marginBottom: 8 }}>
          <div>
            <h3 id="teacher-announcements-title">Announcements</h3>
            <p>{loading ? "Loading notices…" : `${items.length} notices available`}</p>
          </div>
        </div>

        <div className="sa-task-list">
          {items.length ? items.map((item) => (
            <div key={item.id} className="sa-task-row">
              <div className="sa-task-dot" aria-hidden="true">◉</div>
              <div className="sa-task-info">
                <strong>{item.title}</strong>
                <span>{item.body}</span>
                <small>{new Date(item.published_at).toLocaleDateString()}</small>
              </div>
              <span className="sa-badge info">View</span>
            </div>
          )) : (
            <div className="sa-task-row"><div className="sa-task-info"><strong>No announcements published yet.</strong></div></div>
          )}
        </div>
      </div>
    </section>
  );
}
