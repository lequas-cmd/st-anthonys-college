import React from "react";
import type { TeacherDashboardResponse } from "../TeacherDashboard";

type Props = { data: TeacherDashboardResponse | null; loading: boolean; };

export default function AttendancePage({ data, loading }: Props) {
  const classes = data?.classes ?? [];

  return (
    <div className="sa-st-grid2">
      <section className="sa-panel">
        <div className="sa-panel-heading">
          <div>
            <h3>Attendance overview</h3>
            <p>Quick view of all courses in scope</p>
          </div>
        </div>

        <div className="sa-task-list">
          {classes.length ? classes.map((course) => {
            const low = course.roster.filter((student) => student.attendance_pct < 75).length;
            const present = course.roster.filter((student) => student.attendance_pct >= 75).length;
            return (
              <div key={course.id} className="sa-task-row">
                <div className="sa-task-dot" aria-hidden="true">✓</div>
                <div className="sa-task-info">
                  <strong>{course.course_title}</strong>
                  <span>{course.section} • {present} healthy • {low} flagged</span>
                </div>
                <span className="sa-badge warning">{low} flags</span>
              </div>
            );
          }) : (
            <div className="sa-task-row"><div className="sa-task-info"><strong>No attendance data has been loaded.</strong></div></div>
          )}
        </div>
      </section>

      <section className="sa-panel sa-alert-panel">
        <div className="sa-panel-heading">
          <h3>Per-class marking</h3>
          <span className="sa-badge info">Live</span>
        </div>

        {classes.length ? classes.slice(0, 3).map((course) => (
          <div key={`${course.id}-flag`} className="sa-alert-item">
            <span className="sa-alert-symbol blue">i</span>
            <div>
              <strong>{course.course_title}</strong>
              <p>{loading ? "Loading attendance…" : `Mark attendance for ${course.section}`}.</p>
              <small>{course.room}</small>
            </div>
            <a href="#gradebook">Mark →</a>
          </div>
        )) : <div className="sa-alert-item"><span className="sa-alert-symbol blue">i</span><div><strong>No class selected.</strong><p>Assignment data has not loaded.</p></div></div>}
      </section>
    </div>
  );
}
