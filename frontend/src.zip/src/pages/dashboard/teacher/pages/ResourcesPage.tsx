import React from "react";
import type { TeacherDashboardResponse } from "../TeacherDashboard";

type Props = { data: TeacherDashboardResponse | null; loading: boolean; };

export default function ResourcesPage({ data, loading }: Props) {
  const classes = data?.classes ?? [];

  return (
    <div className="sa-st-grid2">
      <section className="sa-panel">
        <div className="sa-panel-heading">
          <div>
            <h3>Weekly timetable</h3>
            <p>{loading ? "Loading timetable…" : `${classes.length} active sections`}</p>
          </div>
        </div>

        <div className="sa-task-list">
          {classes.length ? classes.flatMap((course) => course.timetable.map((slot) => (
            <div key={`${course.id}-${slot.day}`} className="sa-task-row">
              <div className="sa-task-dot" aria-hidden="true">{slot.day.slice(0, 2)}</div>
              <div className="sa-task-info">
                <strong>{course.course_title}</strong>
                <span>{slot.day} • {slot.time}</span>
                <small>{slot.room}</small>
              </div>
              <span className="sa-badge info">{course.section}</span>
            </div>
          ))) : <div className="sa-task-row"><div className="sa-task-info"><strong>No timetable is available.</strong></div></div>}
        </div>
      </section>

      <section className="sa-panel sa-alert-panel">
        <div className="sa-panel-heading">
          <h3>Quick notes</h3>
          <span className="sa-badge success">Current term</span>
        </div>

        {classes.length ? classes.slice(0, 3).map((course) => (
          <div key={`${course.id}-note`} className="sa-alert-item">
            <span className="sa-alert-symbol green">✓</span>
            <div>
              <strong>{course.course_title}</strong>
              <p>{course.next_class}</p>
              <small>{course.room}</small>
            </div>
          </div>
        )) : <div className="sa-alert-item"><span className="sa-alert-symbol green">✓</span><div><strong>No classes scheduled.</strong><p>Assignments are still being loaded.</p></div></div>}
      </section>
    </div>
  );
}
