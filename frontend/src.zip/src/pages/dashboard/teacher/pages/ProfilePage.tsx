import React from "react";
import type { TeacherDashboardResponse } from "../TeacherDashboard";

type Props = { data: TeacherDashboardResponse | null; loading: boolean; };

export default function ProfilePage({ data, loading }: Props) {
  const teacher = data?.teacher;

  return (
    <div className="sa-st-grid2">
      <section className="sa-panel">
        <div className="sa-panel-heading">
          <div>
            <h3>Faculty profile</h3>
            <p>{loading ? "Loading profile…" : "Teaching responsibilities and profile data"}</p>
          </div>
        </div>

        <div className="sa-task-list">
          <div className="sa-task-row">
            <div className="sa-task-dot" aria-hidden="true">{teacher?.first_name?.[0] ?? "I"}{teacher?.last_name?.[0] ?? "N"}</div>
            <div className="sa-task-info">
              <strong>{teacher ? `${teacher.first_name} ${teacher.last_name}` : "Instructor profile"}</strong>
              <span>{teacher?.department ?? "Faculty department"}</span>
            </div>
            <span className="sa-badge success">Active</span>
          </div>
          <div className="sa-task-row">
            <div className="sa-task-dot" aria-hidden="true">#</div>
            <div className="sa-task-info">
              <strong>Employee number</strong>
              <span>{teacher?.employee_number ?? "N/A"}</span>
            </div>
          </div>
          <div className="sa-task-row">
            <div className="sa-task-dot" aria-hidden="true">◌</div>
            <div className="sa-task-info">
              <strong>Access level</strong>
              <span>Instructor / grading permissions</span>
            </div>
          </div>
        </div>
      </section>

      <section className="sa-panel sa-alert-panel">
        <div className="sa-panel-heading">
          <h3>Account actions</h3>
          <span className="sa-badge info">Security</span>
        </div>

        <div className="sa-alert-item">
          <span className="sa-alert-symbol blue">i</span>
          <div>
            <strong>Update password</strong>
            <p>Change the current account password for secure access.</p>
          </div>
        </div>
        <div className="sa-alert-item">
          <span className="sa-alert-symbol green">✓</span>
          <div>
            <strong>Two-factor setup</strong>
            <p>Compliance review is ready for activation with the institution.</p>
          </div>
        </div>
      </section>
    </div>
  );
}
