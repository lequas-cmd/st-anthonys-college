import React from "react";
import type { TeacherClass, TeacherGradeCell } from "../TeacherDashboard";

type Props = {
  classes: TeacherClass[];
  selectedClassId: number | null;
  loading: boolean;
  onSelectClass: (classId: number) => void;
};

export default function GradebookPage({ classes, selectedClassId, loading, onSelectClass }: Props) {
  const selectedClass = classes.find((course) => course.id === selectedClassId) ?? classes[0] ?? null;

  const averageGrade = (student: { current_grade_value: number | null }) => {
    if (student.current_grade_value == null) return "—";
    return `${Math.round(student.current_grade_value)}%`;
  };

  return (
    <section className="sa-panel" aria-labelledby="teacher-gradebook-title">
      <div className="sa-panel-heading">
        <div>
          <h3 id="teacher-gradebook-title">Gradebook</h3>
          <p>{selectedClass ? `${selectedClass.course_title} / ${selectedClass.section}` : "Continuous assessment and class submissions"}</p>
        </div>
        {classes.length > 0 && (
          <select
            aria-label="Select class"
            value={selectedClass?.id ?? ""}
            onChange={(event) => onSelectClass(Number(event.target.value))}
            className="sa-select"
            style={{ minWidth: 180 }}
          >
            {classes.map((course) => (
              <option key={course.id} value={course.id}>{course.course_code} • {course.section}</option>
            ))}
          </select>
        )}
      </div>

      <div className="sa-table-wrap">
        <table className="sa-table">
          <thead>
            <tr>
              <th>Student</th>
              <th>Program</th>
              <th>Attendance</th>
              <th>Current grade</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={5}>Loading gradebook…</td></tr>
            ) : selectedClass && selectedClass.roster.length ? (
              selectedClass.roster.map((student) => {
                const hasGrade = Object.values(student.grades ?? {}).some((entry: TeacherGradeCell) => entry?.value != null);
                return (
                  <tr key={student.id}>
                    <td>{student.first_name} {student.last_name}</td>
                    <td>{student.program}</td>
                    <td>{student.attendance_pct}%</td>
                    <td>{averageGrade(student)}</td>
                    <td><span className={`sa-badge ${hasGrade ? "success" : "warning"}`}>{hasGrade ? "Recorded" : "Pending"}</span></td>
                  </tr>
                );
              })
            ) : (
              <tr><td colSpan={5}>No grade records available.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </section>
  );
}
